using Entidades;

namespace Tests
{
    [TestClass]
    public class BacklogExceptionTest
    {
        [TestMethod]
        public void Constructor_ConMensaje_DeberiaCrearInstancia()
        {
            // Arrange
            string mensaje = "Mensaje de prueba";

            // Act
            BackLogException excepcion = new BackLogException(mensaje);

            // Assert
            Assert.IsNotNull(excepcion);
            Assert.AreEqual(mensaje, excepcion.Message);
            Assert.IsNull(excepcion.InnerException);
        }

        [TestMethod]
        public void Constructor_ConMensajeYExcepcionInterna_DeberiaCrearInstancia()
        {
            // Arrange
            string mensaje = "Mensaje de prueba";
            Exception innerException = new Exception("Excepci�n interna");

            // Act
            BackLogException excepcion = new BackLogException(mensaje, innerException);

            // Assert
            Assert.IsNotNull(excepcion);
            Assert.AreEqual(mensaje, excepcion.Message);
            Assert.AreEqual(innerException, excepcion.InnerException);
        }
    }
}