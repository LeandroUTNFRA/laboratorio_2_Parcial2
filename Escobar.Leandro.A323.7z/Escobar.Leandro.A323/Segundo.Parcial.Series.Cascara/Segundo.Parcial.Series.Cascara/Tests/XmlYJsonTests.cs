using Entidades;

namespace Tests
{
    [TestClass]
    public class XmlYJsonTests
    {
        private Serializadora serializadora;
        private List<Serie> series;
        private string rutaEscritorio;

        [TestInitialize]
        public void Setup()
        {
            serializadora = new Serializadora(); 
            series = new List<Serie>
        {
            new Serie { Nombre = "Serie1", Genero = "Drama" },
            new Serie { Nombre = "Serie2", Genero = "Comedia" }
        };

            
            rutaEscritorio = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        }

        [TestMethod]
        public void Serializar_XML_FormatoCorrecto()
        {
            // Arrange
            string rutaXml = Path.Combine(rutaEscritorio, "BacklogTest.xml");

            // Act
            try
            {
                serializadora.Guardar(series, rutaXml);
            }
            catch (Exception ex)
            {
                Assert.Fail($"Error durante la serializaci�n XML: {ex.Message}");
            }

            // Assert
            Assert.IsTrue(File.Exists(rutaXml), "El archivo XML no se cre� correctamente.");
        }

        [TestMethod]
        public void Serializar_JSON_FormatoCorrecto()
        {
            // Arrange
            string rutaJson = Path.Combine(rutaEscritorio, "SeriesParaVerTest.json");

            // Act
            try
            {
                ((IGuardar<List<Serie>>)serializadora).Guardar(series, rutaJson); 
            }
            catch (Exception ex)
            {
                Assert.Fail($"Error durante la serializaci�n JSON: {ex.Message}");
            }

            // Assert
            Assert.IsTrue(File.Exists(rutaJson), "El archivo JSON no se cre� correctamente.");
        }
    }
}