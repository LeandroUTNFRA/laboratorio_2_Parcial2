﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public static class AccesoDatos
    {
        static string cadenaConexion;
        private static SqlCommand comando;
        private static SqlConnection conexion;

        static AccesoDatos()
        {
            cadenaConexion = @"Data Source=.;Initial Catalog=20240701-SP;Integrated Security=True";
            conexion = new SqlConnection(cadenaConexion);
            comando = new SqlCommand();
            comando.Connection = conexion;
        }

        public static void ActualizarSerie(Serie item)
        {
            try
            {
                conexion.Open();


                comando.CommandText = "UPDATE dbo.series SET alumno = 'Leandro Escobar' WHERE nombre = @nombre AND genero = @genero";

                comando.Parameters.Clear();

                
                comando.Parameters.AddWithValue("@nombre", item.Nombre);
                comando.Parameters.AddWithValue("@genero", item.Genero);
            }
            finally
            {

                conexion.Close();
            }
        }

        public static List<Serie> ObtenerBacklog()
        {
            List<Serie> serie = new List<Serie>();

            try
            {
                conexion.Open();
                comando.CommandText = "SELECT nombre, genero FROM dbo.series";


                using (SqlDataReader dataReader = comando.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        serie.Add(new Serie(dataReader["nombre"].ToString(), dataReader["genero"].ToString()));

                    }
                }
            }
            finally
            {
                conexion.Close();
            }

            return serie;
        }
    }
}
