﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Entidades
{
    public class Serializadora : IGuardar<List<Serie>>
    {
        public Serializadora()
        {
            
        }
        public void Guardar(List<Serie> lista, string ruta)
        {
            try
            {
                using (StreamWriter streamWriter = new StreamWriter(ruta))
                {
                    XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<Serie>));
                    xmlSerializer.Serialize(streamWriter, lista);
                }
            }
            catch (Exception ex)
            { 
                throw new BackLogException("Error al serializar la lista de series en formato XML.", ex);
            }
        }

        void IGuardar<List<Serie>>.Guardar(List<Serie> lista,string ruta)
        {
            try
            {
                using (StreamWriter streamWriter = new StreamWriter(ruta))
                {
                    string json = JsonSerializer.Serialize(lista, new JsonSerializerOptions { WriteIndented = true });
                    streamWriter.Write(json);
                }
            }
            catch (Exception ex)
            {
                throw new BackLogException("Error al serializar la lista de series en formato JSON.", ex);
            }
        }
           
    }
}
