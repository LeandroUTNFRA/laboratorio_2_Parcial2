﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public delegate void DelegadoBacklog(Serie ciudadano);
    public class ManejadorBacklog
    {
        public event DelegadoBacklog SerieParaVer;
        public void IniciarManejador(List<Serie>series)
        {
            Task.Run(() => MoverSeries(series));
        }

        private void MoverSeries(List<Serie> series)
        {
            List<Serie> seriesProcesar = new List<Serie>(series);

            while (seriesProcesar.Count > 0)
            {
                try
                {
                    int index = seriesProcesar.GenerarRandom();
                    Serie serie = seriesProcesar[index];

                    AccesoDatos.ActualizarSerie(serie);

                    Thread.Sleep(1500);

                    SerieParaVer?.Invoke(serie);

                    seriesProcesar.RemoveAt(index);
                }
                catch (Exception ex)
                {
                    throw new BackLogException("Error al procesar serie", ex);
                }
            }
        }
    }
}
