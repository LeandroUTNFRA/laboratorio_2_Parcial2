﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public static class ExtensoraRandom
    {
        public static Random random = new Random();

        public static int GenerarRandom(this List<Serie> series)
        {
            if (series == null || series.Count == 0)
            {
                throw new BackLogException("La lista de series no puede ser nula o estar vacía.");
            }

            return random.Next(0, series.Count);
        }
    }
}
