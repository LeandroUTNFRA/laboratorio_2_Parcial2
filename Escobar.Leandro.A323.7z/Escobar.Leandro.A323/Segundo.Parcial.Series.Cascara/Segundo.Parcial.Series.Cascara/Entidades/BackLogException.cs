﻿namespace Entidades
{
    public class BackLogException:Exception
    {
        public BackLogException(string mensaje):base(mensaje)
        {
                
        }
        public BackLogException(string mensaje, Exception innerExeption):base(mensaje,innerExeption)
        {

        }
    }
}